# Hyperter
Gunakan Command, ~
